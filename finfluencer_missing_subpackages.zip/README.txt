Finfluencer Research Platform — Missing Subpackages Fix
========================================================

Generated: 2026-07-10T21:42:03Z

WHAT THIS IS
------------
A minimal archive containing the two subpackages that were NOT on your
disk when `python -m finfluencer.collect.main` failed with:
    ModuleNotFoundError: No module named 'finfluencer.collect'

Files included (10 total):
    src/finfluencer/collect/            (7 files)
    src/finfluencer/providers/platform/ (3 files)

HOW TO APPLY (Windows PowerShell)
---------------------------------
1) Save this archive to your Downloads folder or to
   D:\Projects\finfluencer_platform\  (either works).

2) Open PowerShell:

   cd D:\Projects\finfluencer_platform

3) Expand the archive INTO the project (over the existing tree):

   # If archive is in the project folder:
   Expand-Archive .\finfluencer_missing_subpackages.zip -DestinationPath . -Force

   # If archive is in Downloads:
   Expand-Archive $HOME\Downloads\finfluencer_missing_subpackages.zip `
                  -DestinationPath . -Force

4) Verify the files landed:

   Test-Path src\finfluencer\collect\main.py
   Test-Path src\finfluencer\providers\platform\youtube.py

   Both should print True.

5) Install the two remaining runtime dependencies (only if you don't
   already have them):

   pip install google-api-python-client youtube-transcript-api typer

6) Now the dry-run works:

   $env:PYTHONPATH = "$PWD\src"
   $env:YT_API_KEY = "dry-run-placeholder"
   $env:ANON_SALT  = "$(python -c 'import secrets; print(secrets.token_hex(32))')"
   python -m finfluencer.collect.main run --stage channels --dry-run --verbose

WHAT DRY-RUN DEMONSTRATES
-------------------------
* config/settings.yaml + config/analysts.yaml load and Pydantic-validate
* Registry finds the YouTube platform provider
* QuotaTracker constructs with the settings.collection.quota values
* CheckpointManager instantiates against output paths
* Logging is configured to JSON-to-stderr (or console with --verbose)
* NO HTTP call is made to YouTube (dry_run flag short-circuits execution)

WHAT DRY-RUN DOES NOT DO
------------------------
It does not touch YouTube, so it cannot detect API-key-invalid,
handle-not-found, or quota-exhausted conditions. Those need a real run
(same command WITHOUT --dry-run) with a genuine YT_API_KEY and verified
handles in config/analysts.yaml.

VERIFICATION
------------
Every file's SHA-256 is listed in manifest.txt inside this archive.
